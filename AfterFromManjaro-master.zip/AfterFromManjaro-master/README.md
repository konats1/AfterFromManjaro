Automatically download and load your selected packages and programs
<br />
<h1>Usage</h1>
<br />
Double click to AfterManjaro.desktop
<br />
or
<br />
Open the terminal in directory and type "python AfterManjaro.py".

<br />
<h2>Index</h2>
<br />
Android Studio(AUR)
<br />
PyCharm(AUR)
<br />
PyCharm(Professional)(AUR)
<br />
Anaconda(AUR)
<br />
Sublime Text(AUR)
<br />
Atom Text Editor(AUR)
<br />
Eclipse(AUR)
<br />
Vim(AUR)
<br />
Geany
<br />
Git(AUR)
<br />
Filezilla(AUR)
<br />
FoxitReader(AUR)
<br />
Ardiuno Ide(AUR)
<br />
Mono Develop(AUR)
<br />
Intellij IDEA(AUR)
<br />
Intellij IDEA(Ultimate)(AUR)
<br />
Visual Studio Code(AUR)
<br />
NetBeans(AUR)
<br />
Mysql Workbench(AUR)
<br />
Ulauncher(AUR)
<br />
Opera(AUR)
<br />
Pepper Flash(AUR)
<br />
Conky(AUR)
<br />
Whatsapp Desktop(AUR)
<br />
TeamViewer(AUR)
<br />
Skype(AUR)
<br />
Mega(AUR)
<br />
BleachBit(AUR)
<br />
Mintstick(AUR)
<br />
VirtualBox(AUR)
<br />
Plank(AUR)
<br />
Krita(AUR)
<br />
RedShift(AUR)
<br />
VokoScreen(AUR)
<br />
WinUsb(AUR)
<br />
Wine(AUR)
<br />
PlayOnLinux(AUR)
<br />
Nylas Mail(AUR)
<br />
Chrome(AUR)
<br />
Terminatör(AUR)
<br />
Spotify(AUR)
<br />
Flatter(AUR)
<br />
Numix Circle Theme(AUR)
<br />
Numix Square Icons(AUR)
<br />
Paper Icons(AUR)
<br />
Update Grub(AUR)
<br />
SSD Trim(AUR)
<br />
Preload(AUR)
<br />
Compiz(AUR)
<br />
Tilix(AUR)
<br />
GCC
<br />
Webstorm
